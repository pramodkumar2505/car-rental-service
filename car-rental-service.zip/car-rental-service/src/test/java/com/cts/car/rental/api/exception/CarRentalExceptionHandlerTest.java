package com.cts.car.rental.api.exception;

import com.cts.car.rental.api.Application;
import com.cts.car.rental.api.advice.CarRentalExceptionHandler;
import com.cts.car.rental.api.controller.CarRentalAppController;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.context.WebApplicationContext;

import static org.mockito.Mockito.when;
import static org.springframework.restdocs.mockmvc.RestDocumentationRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(value = SpringJUnit4ClassRunner.class)
public class CarRentalExceptionHandlerTest {

    @InjectMocks
    CarRentalAppController carRentalAppController;

    @Test
    public void testVehicalOrDistanceRecordNotFoundException() {
        String error = "";
        try {
            carRentalAppController.getVehicalTripExpense("xyz", "", "", "", 2);
        } catch (RecordNotFoundException e) {
            error = e.getMessage();
        }
        Assert.assertNotNull(error);
    }

}
