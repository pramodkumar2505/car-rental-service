package com.cts.car.rental.api.controller;

import com.cts.car.rental.api.exception.RecordNotFoundException;
import com.cts.car.rental.api.model.TripDetail;
import com.cts.car.rental.api.model.TripResponse;
import com.cts.car.rental.api.repository.CarRentalRepository;
import com.cts.car.rental.api.service.CarRentalService;
import com.cts.car.rental.api.util.TripConstants;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.HashMap;
import java.util.Map;

@RunWith(value = SpringJUnit4ClassRunner.class)
public class CarRentalAppControllerTest {
    @InjectMocks
    CarRentalAppController carRentalAppController;

    @Mock
    CarRentalService carRentalService;
    @Mock
    CarRentalRepository carRentalRepository;

    TripDetail tripDetail;
    TripResponse tripResponse;
    Map<String, Double> distanceMap = new HashMap<>();
    Map<String, Integer> vehicalMap = new HashMap<>();

    @Before
    public void setup() {
        distanceMap.put("Pune", 0.0);
        distanceMap.put("Mumbai", 200.0);
        distanceMap.put("Bangalore", 1000.0);
        distanceMap.put("Delhi", 2050.0);
        distanceMap.put("Chennai", 1234.5);

        vehicalMap.put("Swift", 4);
        vehicalMap.put("SUV", 6);
        vehicalMap.put("Van", 7);
        vehicalMap.put("Bus", 30);
        vehicalMap.put("TT", 20);

        tripDetail = new TripDetail("Swift", "Diesel", "NON AC", "Pune-Mumbai-Pune", 2);
        tripResponse = new TripResponse();
        tripResponse.setTotalExpenseDetails(TripConstants.TRIP_EXPENSE_MESSAGE + 10);
        Mockito.when(carRentalRepository.getTripDestinationDistance()).thenReturn(distanceMap);
        Mockito.when(carRentalRepository.getTripVehicalDetail()).thenReturn(vehicalMap);
    }

    @Ignore
    @Test
    public void test_getDieselVehicalTripExpense() {
        Mockito.when(carRentalService.getDieselVehicalTripExpense(tripDetail)).thenReturn(tripResponse);
        ResponseEntity<TripResponse> tripResponseResponseEntity = carRentalAppController.getVehicalTripExpense("Swift", "Diesel", "NON AC", "Pune-Mumbai-Pune", 2);
    }

    @Ignore
    @Test
    public void test_getPetrolVehicalTripExpense() {
        tripDetail.setFeulType("Petrol");
        Mockito.when(carRentalService.getDieselVehicalTripExpense(tripDetail)).thenReturn(tripResponse);
        Assert.assertNotNull(carRentalAppController.getVehicalTripExpense("Swift", "Petrol", "NON AC", "Pune-Mumbai-Pune", 2));
    }


}
