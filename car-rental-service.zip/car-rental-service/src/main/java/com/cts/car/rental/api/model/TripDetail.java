package com.cts.car.rental.api.model;

import java.util.List;

public class TripDetail {
    private String vehicalName;
    private String feulType;
    private String acType;
    private String tripRoute;
    private Integer passengers;

    public TripDetail(String vehicalName, String feulType, String acType, String tripRoute, Integer passengers) {
        this.vehicalName = vehicalName;
        this.feulType = feulType;
        this.acType = acType;
        this.tripRoute = tripRoute;
        this.passengers = passengers;
    }

    public String getVehicalName() {
        return vehicalName;
    }

    public void setVehicalName(String vehicalName) {
        this.vehicalName = vehicalName;
    }

    public String getFeulType() {
        return feulType;
    }

    public void setFeulType(String feulType) {
        this.feulType = feulType;
    }

    public String getAcType() {
        return acType;
    }

    public void setAcType(String acType) {
        this.acType = acType;
    }

    public String getTripRoute() {
        return tripRoute;
    }

    public void setTripRoute(String tripRoute) {
        this.tripRoute = tripRoute;
    }

    public Integer getPassengers() {
        return passengers;
    }

    public void setPassengers(Integer passengers) {
        this.passengers = passengers;
    }

    @Override
    public String toString() {
        return "TripDetail{" +
                "vehicalName='" + vehicalName + '\'' +
                ", feulType='" + feulType + '\'' +
                ", acType='" + acType + '\'' +
                ", tripRoute='" + tripRoute + '\'' +
                ", passengers=" + passengers +
                '}';
    }
}
