package com.cts.car.rental.api.util;

public interface TripConstants {
    public static final String AC = "AC";
    public static final String NON_AC = "NON AC";
    public static final String BIG = "BIG";
    public static final String SMALL = "SMALL";
    public static final String PETROL = "PETROL";
    public static final String DIESEL = "DIESEL";
    public static final String SUV = "SUV";
    public static final String BUS = "BUS";
    public static final String PUNE = "PUNE";
    public static final int STANDARD_CHARGE_PER_KM = 15;
    public static final int LESS_STANDARD_CHARGE_PER_KM = 14;
    public static final int ADDITIONAL_CHARGE_PER_KM = 2;
    public static final int ADDITIONAL_CHARGE_PER_PERSON = 1;
    public static final String TRIP_EXPENSE_MESSAGE = "Total Trip Expense is : ";
}
