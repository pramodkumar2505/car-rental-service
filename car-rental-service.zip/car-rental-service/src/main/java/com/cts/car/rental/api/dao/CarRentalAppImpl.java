package com.cts.car.rental.api.dao;

import com.cts.car.rental.api.exception.RecordNotFoundException;
import com.cts.car.rental.api.repository.CarRentalRepository;

import java.util.HashMap;
import java.util.Map;

public class CarRentalAppImpl implements CarRentalRepository {

    @Override
    public Map<String, Double> getTripDestinationDistance() throws RecordNotFoundException {
        Map<String, Double> distanceMap = new HashMap<>();
        distanceMap.put("Pune", 0.0);
        distanceMap.put("Mumbai", 200.0);
        distanceMap.put("Bangalore", 1000.0);
        distanceMap.put("Delhi", 2050.0);
        distanceMap.put("Chennai", 1234.5);
        return distanceMap;
    }

    @Override
    public Map<String, Integer> getTripVehicalDetail()throws RecordNotFoundException{
        Map<String, Integer> vehicalMap = new HashMap<>();
        vehicalMap.put("Swift", 4);
        vehicalMap.put("SUV", 6);
        vehicalMap.put("Van", 7);
        vehicalMap.put("Bus", 30);
        vehicalMap.put("TT", 20);
        return vehicalMap;
    }

}
