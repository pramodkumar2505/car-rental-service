package com.cts.car.rental.api.service;

import com.cts.car.rental.api.exception.RecordNotFoundException;
import com.cts.car.rental.api.model.TripDetail;
import com.cts.car.rental.api.model.TripResponse;
import com.cts.car.rental.api.repository.CarRentalRepository;
import com.cts.car.rental.api.util.TripConstants;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
public class CarRentalService {

    private static Logger logger = LogManager.getLogger(CarRentalService.class);

    @Autowired
    private CarRentalRepository carRentalRepository;

    public CarRentalService(CarRentalRepository carRentalRepository) {
        this.carRentalRepository = carRentalRepository;
    }

    public TripResponse getPetrolVehicalTripExpense(TripDetail tripDetail) {
        logger.info("Car Rental App Service For Petrol Vehical : "+tripDetail.toString());
        TripResponse tripResponse = new TripResponse();
        double totalExpense = calculateTripExpense(tripDetail, false);
        tripResponse.setTotalExpenseDetails(TripConstants.TRIP_EXPENSE_MESSAGE+totalExpense);
        return tripResponse;
    }

    public TripResponse getDieselVehicalTripExpense(TripDetail tripDetail) {
        logger.info("Car Rental App Service For Diesel Vehical : "+tripDetail.toString());
        TripResponse tripResponse = new TripResponse();
        double totalExpense;
        if (TripConstants.SUV.equalsIgnoreCase(tripDetail.getVehicalName())) {
            totalExpense = calculateTripExpense(tripDetail, true);
        } else {
            totalExpense = calculateTripExpense(tripDetail, false);
            if (TripConstants.BUS.equalsIgnoreCase(tripDetail.getVehicalName())) {
                double discount = (totalExpense * 2) / 100;
                totalExpense -= discount;
                logger.info("Car Rental App Service Discount for Bus is : "+discount+" on expense : "+totalExpense);
            }
        }
        tripResponse.setTotalExpenseDetails(TripConstants.TRIP_EXPENSE_MESSAGE+totalExpense);
        return tripResponse;
    }

    private double calculateTripExpense(TripDetail tripDetail, boolean suvFlag) {
        double totalExpense=0;
        double totalDistance=0;
        Map<String, Integer> vehicalMap = carRentalRepository.getTripVehicalDetail();
        Map<String, Double> distanceMap = carRentalRepository.getTripDestinationDistance();
        if (vehicalMap.containsKey(tripDetail.getVehicalName())) {
            String[] source = tripDetail.getTripRoute().split("-");
            int limit = vehicalMap.get(tripDetail.getVehicalName());
            if (distanceMap.containsKey(source[1])) {
                totalDistance = distanceMap.get(source[1]);
                totalExpense = getTotalExpense(tripDetail, limit, totalDistance, false, source);
            } else {
                logger.error("Invalid Trip Route : " + tripDetail.getTripRoute());
                throw new RecordNotFoundException("Invalid Trip Route : " + tripDetail.getTripRoute());
            }
        } else {
            logger.error("Invalid Vehical : " + tripDetail.getVehicalName());
            throw new RecordNotFoundException("Invalid Vehical : " + tripDetail.getVehicalName());
        }
        return totalExpense;
    }

    private double getTotalExpense(TripDetail tripDetail, int limit, double totalDistance, boolean suvFlag, String... source) {
        double charge = 0;
        if (TripConstants.AC.equalsIgnoreCase(tripDetail.getAcType())
                || (suvFlag)) {
            if (suvFlag || TripConstants.BUS.equalsIgnoreCase(tripDetail.getVehicalName()))
                charge = TripConstants.LESS_STANDARD_CHARGE_PER_KM + TripConstants.ADDITIONAL_CHARGE_PER_KM;
            else
                charge = TripConstants.STANDARD_CHARGE_PER_KM + TripConstants.ADDITIONAL_CHARGE_PER_KM;
        } else if (TripConstants.NON_AC.equalsIgnoreCase(tripDetail.getAcType())) {
            if(TripConstants.BUS.equalsIgnoreCase(tripDetail.getVehicalName()))
                charge = TripConstants.LESS_STANDARD_CHARGE_PER_KM;
            else
                charge = TripConstants.STANDARD_CHARGE_PER_KM;
        }
        charge = addExtraCharges(tripDetail.getPassengers(), limit, charge);
        if(source.length>2) {
            totalDistance = addTwoWayTripCharges(totalDistance, source);
        }
        logger.info("Total Trip "+tripDetail.getTripRoute()+" Expense is : "+totalDistance * charge+" for distance : "+totalDistance+"KM.");
        return totalDistance * charge;
    }

    private double addExtraCharges(Integer passengers, int limit, double charge) {
        if (passengers.intValue() > limit) {
            charge += TripConstants.ADDITIONAL_CHARGE_PER_PERSON;
            logger.info("Add extra change per person while exceeds passengers limit for available vehical.");
        }
        return charge;
    }

    private double addTwoWayTripCharges(double totalDistance, String... source) {
        if (isTwoWayTrip(source)) {
            totalDistance += totalDistance;
        }
        return totalDistance;
    }

    private boolean isTwoWayTrip(String... source) {
        return (TripConstants.PUNE.equalsIgnoreCase(source[0]) && TripConstants.PUNE.equalsIgnoreCase(source[2])) ? true : false;
    }

}
