package com.cts.car.rental.api.controller;

import com.cts.car.rental.api.exception.RecordNotFoundException;
import com.cts.car.rental.api.model.TripDetail;
import com.cts.car.rental.api.model.TripResponse;
import com.cts.car.rental.api.service.CarRentalService;
import com.cts.car.rental.api.util.TripConstants;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/car-rental")
@Profile("dev")
public class CarRentalAppController {

    private static Logger logger = LogManager.getLogger(CarRentalAppController.class);

    @Value("${car.rental.app}")
    private String environment;

    @Autowired
    private CarRentalService carRentalService;

    public CarRentalAppController(CarRentalService carRentalService) {
        this.carRentalService = carRentalService;
    }

    @GetMapping("expense/{vehicalName}/{feulType}/{acType}/{tripRoute}/{passengers}")
    public ResponseEntity<TripResponse> getVehicalTripExpense(@PathVariable String vehicalName, @PathVariable String feulType, @PathVariable String acType, @PathVariable String tripRoute, @PathVariable Integer passengers) {
        logger.info("Car Rental App Service Environment Profile is : "+environment);
        TripResponse tripResponse = null;
        TripDetail tripDetail = new TripDetail(vehicalName, feulType, acType, tripRoute, passengers);
        if (TripConstants.PETROL.equalsIgnoreCase(tripDetail.getFeulType())) {
            tripResponse = carRentalService.getPetrolVehicalTripExpense(tripDetail);
        } else if (TripConstants.DIESEL.equalsIgnoreCase(tripDetail.getFeulType())) {
            tripResponse = carRentalService.getDieselVehicalTripExpense(tripDetail);
        }
        if (tripResponse == null) {
            logger.error("Invalid Vehical : " + tripDetail.getVehicalName() + " Or Trip Route : " + tripDetail.getTripRoute());
            throw new RecordNotFoundException("Invalid Vehical : " + tripDetail.getVehicalName() + " Or Trip Route : " + tripDetail.getTripRoute());
        }
        logger.info("tripResponse is ::::: "+tripResponse.toString());
        return new ResponseEntity<>(tripResponse, HttpStatus.OK);
    }
}
