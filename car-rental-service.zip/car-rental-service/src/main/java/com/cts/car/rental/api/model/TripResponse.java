package com.cts.car.rental.api.model;

public class TripResponse {
    private String totalExpenseDetails;

    public String getTotalExpenseDetails() {
        return totalExpenseDetails;
    }

    public void setTotalExpenseDetails(String totalExpenseDetails) {
        this.totalExpenseDetails = totalExpenseDetails;
    }

    @Override
    public String toString() {
        return "TripResponse{" +
                "totalExpenseDetails='" + totalExpenseDetails + '\'' +
                '}';
    }
}
