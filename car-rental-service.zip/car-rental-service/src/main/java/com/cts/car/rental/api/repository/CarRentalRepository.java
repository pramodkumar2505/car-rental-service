package com.cts.car.rental.api.repository;

import com.cts.car.rental.api.exception.RecordNotFoundException;
import org.springframework.stereotype.Repository;

import java.util.Map;

@Repository
public interface CarRentalRepository {
    public Map<String, Double> getTripDestinationDistance() throws RecordNotFoundException;
    public Map<String, Integer> getTripVehicalDetail() throws RecordNotFoundException;
}
